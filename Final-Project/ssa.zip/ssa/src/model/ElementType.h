#ifndef ELEMENTTYPE_H
#define ELEMENTTYPE_H

enum ElementType {
    SCENE_HEADING,
    ACTION,
    CHARACTER,
    DIALOGUE,
    PARENTHETICAL,
    TRANSITION,
    SHOT
};

#endif // ELEMENTTYPE_H
